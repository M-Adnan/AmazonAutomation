﻿using System;
using AmazonTestLogger;
using OpenQA.Selenium;

namespace AmazonAutomationFramework
{
    public class HomePage
    {
        public static void GoTo(TestEnvironment env)
        {
            Logger.AddCustomMsg("Goto ", env.ToString(), " environment");

            switch (env)
            {
                case TestEnvironment.QA:
                    Driver.Instance.Navigate().GoToUrl("http://qa.amazon.com");
                    break;

                case TestEnvironment.Staging:
                    Driver.Instance.Navigate().GoToUrl("http://staging.amazon.com");
                    break;

                case TestEnvironment.Live:
                    Driver.Instance.Navigate().GoToUrl("https://www.amazon.co.uk/");
                    break;
            }
        }

        public static bool IsDisplayed
        {
            get
            {
                try
                {
                    return Driver.FindElementWithTimeout(By.Id("nav-signin-tooltip"),40, "Home page not displayed in 40 secs").Displayed;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public static bool IsSignedin
        {
            get
            {
                try
                {
                    IWebElement signinElement = Driver.Instance.FindElement(By.Id("nav-link-yourAccount"));
                    IWebElement signinSpan = signinElement.FindElement(By.ClassName("nav-line-1"));
                    string signinSpanText = signinSpan.Text;
                    if (signinSpanText.Contains("Hello,"))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
    }
}
