﻿using OpenQA.Selenium;
using System;

namespace AmazonAutomationFramework
{
    public class RecommendationPage
    {
        public static bool IsDisplayed
        {
            get
            {
                try
                {
                    return Driver.FindElementWithTimeout(By.Id("ys-center"), 40, "Home page not displayed in 40 secs").Displayed;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
    }
}
