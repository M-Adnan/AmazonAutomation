﻿using OpenQA.Selenium;
using System;
using AmazonTestLogger;

namespace AmazonAutomationFramework
{
    public class SigninPage
    {
        public static bool IsDisplayed
        {
            get
            {
                try
                {
                    return Driver.FindElementWithTimeout(By.Id("signInSubmit"), 40, "Signin page not displayed in 40 secs").Displayed;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public static void TypeAgentUserName(string userName)
        {
            Logger.AddTypeAction(userName, "Username text box");
            var emailTextBox = Driver.Instance.FindElement(By.Id("ap_email"));
            emailTextBox.SendKeys(userName);
        }

        public static void TypeAgentPassword(string password)
        {
            Logger.AddTypeAction(password, "Password text box");
            var passwordTextBox = Driver.Instance.FindElement(By.Id("ap_password"));
            passwordTextBox.SendKeys(password);
        }

        public static void ClickLoginButton()
        {
            Logger.AddClickAction("Login button");
            var signinButton = Driver.Instance.FindElement(By.Id("signInSubmit"));
            signinButton.Click();
        }


        public static LoginCommand LoginAs(string email)
        {
            return new LoginCommand(email);
        }
    }

    public class LoginCommand
    {
        private readonly string email;
        private string password;

        public LoginCommand(String email)
        {
            this.email = email;
        }

        public LoginCommand WithPassword(string password)
        {
            this.password = password;
            return this;
        }

        public void Login()
        {

            SigninPage.TypeAgentUserName(email);

            SigninPage.TypeAgentPassword(password);

            SigninPage.ClickLoginButton();

        }
    }
}
