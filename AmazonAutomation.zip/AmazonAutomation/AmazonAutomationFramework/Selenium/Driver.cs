﻿using System;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;

namespace AmazonAutomationFramework
{
    public class Driver
    {
        public static IWebDriver Instance { get; set; }
        public static bool WaitOff { get; internal set; }
        public static int DefaultImplicitWait { get; internal set; }

        public static void Initialise(string TestingEnviorment, string SeleniumBrowser)
        {
            switch (SeleniumBrowser.Trim().ToLower())
            {
                case "firefox":
                    Instance = new FirefoxDriver();
                    SetDefaultImplicitWait(5);
                    Instance.Manage().Window.Maximize();
                    break;

                case "chrome":
                    Instance = new ChromeDriver(@"\Drivers\");
                    SetDefaultImplicitWait(5);
                    Instance.Manage().Window.Maximize();
                    break;

                case "ie":
                    Instance = new InternetExplorerDriver("\\Drivers\\");
                    SetDefaultImplicitWait(5);
                    Instance.Manage().Window.Maximize();
                    break;
                default:
                    throw new Exception(string.Format("Browser {0} unknown", SeleniumBrowser));
            }
        }

        public static void Close()
        {
            Driver.Instance.Quit();
        }

        public static IWebElement FindElementWithTimeout(By by, int timeoutInSeconds, string errMsg)
        {
            Driver.TurnOffWait();
            var wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(timeoutInSeconds));
            try
            {
                var webelement = wait.Until(drv => drv.FindElement(by));
                Driver.TurnOnWait();
                return webelement;
            }
            catch
            {
                throw new Exception(errMsg);
            }
        }

        internal static void Wait(TimeSpan timeSpan)
        {
            Thread.Sleep((int)timeSpan.TotalSeconds * 1000);
        }

        public static void WaitForPagetoLoad(int seconds)
        {
            Driver.Instance.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(seconds));
        }

        internal static void SetDefaultImplicitWait(int seconds)
        {
            Instance.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(seconds));
        }

        internal static void TurnOffWait()
        {
            if (Driver.WaitOff) return;
            Driver.Instance.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(0));
            Driver.WaitOff = true;
        }

        internal static void TurnOnWait()
        {
            if (Driver.WaitOff)
            {
                if (DefaultImplicitWait == 0)
                {
                    Driver.Instance.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(5));
                }
                else
                {
                    Driver.Instance.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(DefaultImplicitWait));
                }
                Driver.WaitOff = false;
            }
        }
    }
}
