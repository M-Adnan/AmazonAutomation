﻿
namespace AmazonAutomationFramework
{
    public enum TestEnvironment
    {
        Custom,
        QA,
        Staging,
        Live,
    }
}
