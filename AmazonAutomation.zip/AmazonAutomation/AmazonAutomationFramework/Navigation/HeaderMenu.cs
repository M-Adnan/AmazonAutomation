﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Collections.ObjectModel;
using AmazonTestLogger;

namespace AmazonAutomationFramework
{
    public class HeaderMenu
    {
        public class YourAccount
        {
            public class Links
            {
                internal static IWebElement getYourAccountMenu()
                {
                    return Driver.Instance.FindElement(By.Id("nav-link-yourAccount"));
                }

                internal static Actions getActionsBuilder()
                {
                    return new Actions(Driver.Instance);
                }

                internal static bool SelectLink(string linkName)
                {
                    Logger.AddSelectAction(linkName, "from 'Your Recommendation' drop down");
                    IWebElement yourAccountMenu = getYourAccountMenu();
                    IWebElement menuElement = Driver.Instance.FindElement(By.Id("nav-flyout-anchor"));
                    Actions builder = getActionsBuilder();
                    Driver.WaitForPagetoLoad(30);
                    Driver.Wait(TimeSpan.FromSeconds(3));
                    builder.MoveToElement(yourAccountMenu).Perform();
                    ReadOnlyCollection<IWebElement> yourAcountLinks = menuElement.FindElements(By.TagName("a"));
                    foreach (IWebElement link in yourAcountLinks)
                    {
                        if (link.Text == linkName)
                        {
                            link.Click();
                            return true;
                        }
                    }
                    return false;
                }

                public class Signin
                {
                    public static void Select()
                    {
                        Logger.AddSelectAction("Sign in", "from 'Your Recommendation' drop down");
                        IWebElement signinLink = Driver.Instance.FindElement(By.Id("nav-link-yourAccount"));
                        signinLink.Click();
                    }
                }

                public class YourRecommendations
                {
                    public static void Select()
                    {
                        if (!Links.SelectLink("Your Recommendations"))
                        {
                            throw new System.InvalidOperationException("Your Recommendations link cannot be found or selected");
                        }
                    }
                }
            }
        }
    }
}
