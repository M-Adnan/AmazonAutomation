﻿
namespace AmazonTestLogger
{
    public class Logger
    {
        public static readonly log4net.ILog log;

        static Logger()
        {
            log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }

        public static void AddTypeAction(string value, string description)
        {
            log.Info("Type \"" + value + "\" in " + description);
        }

        public static void AddClickAction(string description)
        {
            log.Info("Click " + description);
        }

        public static void AddSelectAction(string value, string description)
        {
            log.Info("Select " + value + " " + description);
        }

        public static void AddCustomMsg(string description1, string value, string description2)
        {
            log.Info(description1 + " " + value + " " + description2);
        }

        public static void AddCustomMsg(string description1, string value)
        {
            log.Info(description1 + " " + value);
        }

        public static void AddCustomMsg(string description1)
        {
            log.Info(description1);
        }
    }
}
