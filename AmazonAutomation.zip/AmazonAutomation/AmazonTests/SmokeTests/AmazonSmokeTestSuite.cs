﻿using NUnit.Framework;
using AmazonAutomationFramework;

namespace AmazonTests.SmokeTests
{
    [TestFixture]
    public class AmazonSmokeTestSuite:BaseTestClass
    {
        [Test]
        [Category("SmokeTest")]
        public void User_Successful_Login()
        {
            //Assert.IsTrue(HomePage.IsDisplayed, "Home page not displayed in 40 secs");

            HeaderMenu.YourAccount.Links.Signin.Select();

            Assert.IsTrue(SigninPage.IsDisplayed, "Signin page not displayed in 40 secs");

            SigninPage.LoginAs("dashingdani@gmail.com").WithPassword("Passw0rd!480").Login();

            Assert.IsTrue(HomePage.IsSignedin, "User is not signed in");

            HeaderMenu.YourAccount.Links.YourRecommendations.Select();

            Assert.IsTrue(RecommendationPage.IsDisplayed, "Recommendation page not displayed in 40 secs");

        }
    }
}
