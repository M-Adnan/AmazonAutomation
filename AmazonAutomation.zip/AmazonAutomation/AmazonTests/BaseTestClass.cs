﻿using NUnit.Framework;
using System;
using AmazonTestLogger;
using AmazonAutomationFramework;
using AmazonTests.Properties;

namespace AmazonTests
{
    [TestFixture]
    public class BaseTestClass
    {
        [SetUp]
        public void Initialise()
        {
            Logger.AddCustomMsg("Test Name: ", TestContext.CurrentContext.Test.FullName);
            Logger.AddCustomMsg("Steps to replicate:");

            Driver.Initialise(Settings.Default.TestingEnvironment, Settings.Default.SeleniumBrowser);

            HomePage.GoTo((TestEnvironment)Enum.Parse(typeof(TestEnvironment), Settings.Default.TestingEnvironment));
        }

        [TearDown]
        public void Cleanup()
        {
            Driver.Close();
        }
    }
}
